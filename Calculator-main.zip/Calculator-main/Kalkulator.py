import sys, time

print("Kalkulator")

def dodawanie(x, y):
    return x + y

def odejmowanie(x, y):
    return x - y

def mnozenie(x, y):
    return x * y

def dzielenie(x, y):
    return x / y

def exit():
    print("Czy chcesz wyjść? ")
    choice_exit = input("Tak/Nie: ")
    if choice_exit == "Tak":
        run = False
        sys.exit()
    elif choice_exit == "Nie":
        main()

def exit_5():
    print("Czy na pewno chcesz wyjść? ")
    choice_exit = input("Tak/Nie: ")
    if choice_exit == "Tak":
        run = False
        sys.exit()
    elif choice_exit == "Nie":
        main()

def main():
    run = True
    while run:
        time.sleep(0.5)
        print("_____MENU_____")
        time.sleep(0.5)
        print("1. Dodawanie")
        time.sleep(0.5)
        print("2. Odejmowanie")
        time.sleep(0.5)
        print("3. Mnożenie")
        time.sleep(0.5)
        print("4. Dzielenie")
        time.sleep(0.5)
        print("5. Wyjście")
        time.sleep(0.5)

        choice = int(input("Podaj liczbę z Menu: "))
        time.sleep(0.5)

        if choice == 5:
           exit_5()
        if choice == 1:
            x = int(input("Podaj 1 liczbe: "))
            y = int(input("Podaj 2 liczbe: "))
            print("Wynik: ",dodawanie(x, y))
            time.sleep(0.5)
            exit()
        elif choice == 2:
            x = int(input("Podaj 1 liczbe: "))
            y = int(input("Podaj 2 liczbe: "))
            print("Wynik: ",odejmowanie(x, y))
            time.sleep(0.5)
            exit()
        elif choice == 3:
            x = int(input("Podaj 1 liczbe: "))
            y = int(input("Podaj 2 liczbe: "))
            print("Wynik: ",mnozenie(x, y))
            time.sleep(0.5)
            exit()
        elif choice == 4:
            x = int(input("Podaj 1 liczbe: "))
            y = int(input("Podaj 2 liczbe: "))
            print("Wynik: ",dzielenie(x, y))
            time.sleep(0.5)
            exit()
        else:
            print("Wybrałeś nie właściwą opcje! spróbuj ponownie")
            main()


if __name__ == "__main__":
    main()
